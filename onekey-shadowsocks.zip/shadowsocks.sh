#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
. shadowsocks-debian.sh
. shadowsocks-centos.sh

clear
echo
echo "#############################################################"
echo "# One click Install Shadowsocks-Python Manyusers Version    #"
echo "# Author: JulySnow <603723963@qq.com>                       #"
echo "# Thanks: @zd423 <http://zdfans.com> @glzhaojin <zhaoj.in>  #"
echo "#############################################################"
echo

Get_Dist_Name()
{
    if grep -Eqi "CentOS" /etc/issue || grep -Eq "CentOS" /etc/*-release; then
        DISTRO='CentOS'
        PM='yum'
    elif grep -Eqi "Debian" /etc/issue || grep -Eq "Debian" /etc/*-release; then
        DISTRO='Debian'
        PM='apt'
    elif grep -Eqi "Ubuntu" /etc/issue || grep -Eq "Ubuntu" /etc/*-release; then
        DISTRO='Ubuntu'
        PM='apt'		
	else
        DISTRO='unknow'
    fi
}

Get_Dist_Name

if [ "$DISTRO" == "CentOS" ]; then
	# CentOS
	CentOS_Install
	fi
	if [[ "$DISTRO" == "Ubuntu" ]] || [[ "$DISTRO" == "Debian" ]]; then
	# Debian/Ubuntu
	Debian_Ubuntu_Install
	fi