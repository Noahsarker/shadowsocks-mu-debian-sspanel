#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

clear
echo
echo "#############################################################"
echo "# One click Install Shadowsocks-Python Manyusers Version    #"
echo "# Author: JulySnow <603723963@qq.com>                       #"
echo "# Thanks: @zd423 <zdfans.com> @glzhaojin <zhaoj.in>         #"
echo "#############################################################"
echo

Debian_Ubuntu_Install()
{
apt-get -y update
apt-get -y upgrade
apt-get -y install python-pip m2crypto git vim
apt-get -y install build-essential
cd /root
git clone -b stable https://github.com/jedisct1/libsodium
cd /root/libsodium
./configure
make
make install
ldconfig

cd /bin
wget https://github.com/JulySnow/shadowsocks-mu-debian-sspanel/raw/master/shadowsocks -O /bin/shadowsocks

cd /root
pip install cymysql
git clone -b manyuser https://github.com/glzjin/shadowsocks.git
apt-get -y install python-pip python-m2crypto supervisor
mkdir -p /etc/supervisor/conf.d/
cat >>/etc/supervisor/conf.d/shadowsocks.conf<< EOF
[program:shadowsocks]
command=python /root/shadowsocks/server.py
directory=/root/shadowsocks/
autostart=true
autorestart=true
user=root
EOF

pip install speedtest-cli

cat >>/etc/security/limits.conf<< EOF
* soft nofile  512000
* hard nofile 1024000
* soft nproc 512000
* hard nproc 512000
EOF


cat >>/etc/sysctl.conf<<EOF
fs.file-max = 1024000
net.core.rmem_max = 67108864
net.core.wmem_max = 67108864
net.core.netdev_max_backlog = 250000
net.core.somaxconn = 4096
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fin_timeout = 30
net.ipv4.tcp_keepalive_time = 1200
net.ipv4.ip_local_port_range = 10000 65000
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.tcp_max_tw_buckets = 5000
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_mem = 25600 51200 102400
net.ipv4.tcp_rmem = 4096 87380 67108864
net.ipv4.tcp_wmem = 4096 65536 67108864
net.ipv4.tcp_mtu_probing = 1
net.ipv4.tcp_congestion_control = hybla
EOF


sed -i "s/exit 0/ulimit -n 512000/g" /etc/rc.local
cat >>/etc/rc.local<<EOF
supervisorctl restart all
exit 0
EOF

echo "ulimit -n 512000" >>/etc/default/supervisor
echo "ulimit -n 512000" >>/etc/profile
source /etc/default/supervisor
source /etc/profile
sysctl -p
ulimit -n 51200

host="127.0.0.1"
read -p "输入MySQL,IP地址或者域名: " host
sed -i "s/MYSQL_HOST = '127.0.0.1'/MYSQL_HOST = '${host}'/g" /root/shadowsocks/apiconfig.py

username="root"
read -p "输入MySQL,用户名: " username
sed -i "s/MYSQL_USER = 'ss'/MYSQL_USER = '${username}'/g" /root/shadowsocks/apiconfig.py

password="root"
read -p "输入MySQL,登录密码: " password
sed -i "s/MYSQL_PASS = 'ss'/MYSQL_PASS = '${password}'/g" /root/shadowsocks/apiconfig.py

db="shadowsocks"
read -p "输入MySQL,数据库名: " db
sed -i "s/MYSQL_DB = 'shadowsocks'/MYSQL_DB = '${db}'/g" /root/shadowsocks/apiconfig.py

TRANSFER_MUL="1.0"
read -p "输入流量比率: " TRANSFER_MUL
echo "TRANSFER_MUL=${TRANSFER_MUL}" >>/root/shadowsocks/apiconfig.py

NODE_ID = 1
read -p "请输入此节点在面板中的ID号: " NODE_ID
sed -i "s/NODE_ID = 1/NODE_ID = '${NODE_ID}'/g" /root/shadowsocks/apiconfig.py

SPEEDTEST = 6
read -p "输入测速时间,默认为6小时,0为关闭: " SPEEDTEST
sed -i "s/SPEEDTEST = 6/SPEEDTEST = '${SPEEDTEST}'/g" /root/shadowsocks/apiconfig.py

CLOUDSAFE = 1
read -p "是否开启云安全,自动上报与下载封禁IP,1为开启,0为关闭: " CLOUDSAFE
sed -i "s/CLOUDSAFE = 1/CLOUDSAFE = '${CLOUDSAFE}'/g" /root/shadowsocks/apiconfig.py

ANTISSATTACK = 0
read -p "是否开启自动封禁SS密码和加密方式错误的 IP,1为开启,0为关闭: " ANTISSATTACK
sed -i "s/ANTISSATTACK = 0/ANTISSATTACK = '${ANTISSATTACK}'/g" /root/shadowsocks/apiconfig.py

AUTOEXEC = 1
read -p "是否接受上级下发的命令,1为开启,0为关闭: " AUTOEXEC
sed -i "s/AUTOEXEC = 1/AUTOEXEC = '${AUTOEXEC}'/g" /root/shadowsocks/apiconfig.py

cd /root/shadowsocks
cp apiconfig.py userapiconfig.py
cp config.json user-config.json

supervisorctl reload
supervisorctl restart all
ulimit -n 51200

echo
echo "#############################################################"
echo "# One click Install Shadowsocks-Python Manyusers Version    #"
echo "# Author: JulySnow <603723963@qq.com>                       #"
echo "# Thanks: @zd423 <http://zdfans.com> @glzhaojin <zhaoj.in>  #"
echo "#############################################################"
echo
echo "恭喜您!Shadowsocks Python多用户版安装并与前段SS-Panel对接完成!"
echo "此脚本仅支持v3魔改版! 其他版本勿用!"
echo "查看日志:supervisorctl tail -f shadowsocks stderr"
}